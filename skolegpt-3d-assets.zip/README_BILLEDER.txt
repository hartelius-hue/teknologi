24 selvstændige 3D-bannere til hartelius-hue/teknologi.
ZIP indeholder assets/3d/level-1.webp ... level-4.webp og assets/3d/mission-01.webp ... mission-20.webp.
Læg disse filer i GitHub-repositoryets rod, så sti og filnavne bevares.
